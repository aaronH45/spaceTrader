let name1 = ""
let name2 = ""
let name3 = ""
let name4 = ""
let name5 = ""
let name6 = ""
let name7 = ""
let name8 = ""
let name9 = ""
let name10 = ""

let buy1 = ""
let buy2 = ""
let buy3 = ""
let buy4 = ""
let buy5 = ""
let buy6 = ""
let buy7 = ""
let buy8 = ""
let buy9 = ""
let buy10 = ""

let sell1 = ""
let sell2 = ""
let sell3 = ""
let sell4 = ""
let sell5 = ""
let sell6 = ""
let sell7 = ""
let sell8 = ""
let sell9 = ""
let sell10 = ""

function fillValues() {
    getValues();
    document.getElementById("inventory_name1").value = name1;
    document.getElementById("inventory_name2").value = name2;
    document.getElementById("inventory_name3").value = name3;
    document.getElementById("inventory_name4").value = name4;
    document.getElementById("inventory_name5").value = name5;
    document.getElementById("inventory_name6").value = name6;
    document.getElementById("inventory_name7").value = name7;
    document.getElementById("inventory_name8").value = name8;
    document.getElementById("inventory_name9").value = name9;
    document.getElementById("inventory_name10").value = name10;

    document.getElementById("inventory_buy1").value = buy1;
    document.getElementById("inventory_buy2").value = buy2;
    document.getElementById("inventory_buy3").value = buy3;
    document.getElementById("inventory_buy4").value = buy4;
    document.getElementById("inventory_buy5").value = buy5;
    document.getElementById("inventory_buy6").value = buy6;
    document.getElementById("inventory_buy7").value = buy7;
    document.getElementById("inventory_buy8").value = buy8;
    document.getElementById("inventory_buy9").value = buy9;
    document.getElementById("inventory_buy10").value = buy10;

    document.getElementById("inventory_sell1").value = sell1;
    document.getElementById("inventory_sell2").value = sell2;
    document.getElementById("inventory_sell3").value = sell3;
    document.getElementById("inventory_sell4").value = sell4;
    document.getElementById("inventory_sell5").value = sell5;
    document.getElementById("inventory_sell6").value = sell6;
    document.getElementById("inventory_sell7").value = sell7;
    document.getElementById("inventory_sell8").value = sell8;
    document.getElementById("inventory_sell9").value = sell9;
    document.getElementById("inventory_sell10").value = sell10;
}

function getValues() {

}